'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
const fmtTime=s=>{if(!isFinite(s)||s<0)s=0;return Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0')};
const dpr=Math.min(2,window.devicePixelRatio||1);
const RANGE=0.16; // pitch fader range, +/-16%

/* ---------- audio graph ---------- */
const AC=window.AudioContext||window.webkitAudioContext;
const ctx=new AC({latencyHint:'interactive'});
const master={in:ctx.createGain(),vol:ctx.createGain(),comp:ctx.createDynamicsCompressor(),split:ctx.createChannelSplitter(2),anL:ctx.createAnalyser(),anR:ctx.createAnalyser()};
master.vol.gain.value=.8;
master.comp.threshold.value=-10;master.comp.ratio.value=4;master.comp.attack.value=.005;master.comp.release.value=.15;
master.in.connect(master.vol);master.vol.connect(master.comp);master.comp.connect(ctx.destination);
master.comp.connect(master.split);master.split.connect(master.anL,0);master.split.connect(master.anR,1);
master.anL.fftSize=master.anR.fftSize=512;

function makeImpulse(sec,decay){const n=Math.floor(ctx.sampleRate*sec),b=ctx.createBuffer(2,n,ctx.sampleRate);
  for(let c=0;c<2;c++){const d=b.getChannelData(c);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,decay)}return b}

const fx={in:ctx.createGain()};
fx.delay=ctx.createDelay(2);fx.delay.delayTime.value=.375;
fx.fb=ctx.createGain();fx.fb.gain.value=.4;
fx.fbLp=ctx.createBiquadFilter();fx.fbLp.type='lowpass';fx.fbLp.frequency.value=3200;
fx.echoWet=ctx.createGain();fx.echoWet.gain.value=0;
fx.in.connect(fx.delay);fx.delay.connect(fx.fbLp);fx.fbLp.connect(fx.fb);fx.fb.connect(fx.delay);fx.delay.connect(fx.echoWet);fx.echoWet.connect(master.in);
fx.conv=ctx.createConvolver();fx.conv.buffer=makeImpulse(2.4,2.6);
fx.revWet=ctx.createGain();fx.revWet.gain.value=0;
fx.in.connect(fx.conv);fx.conv.connect(fx.revWet);fx.revWet.connect(master.in);
fx.fl=ctx.createDelay(.05);fx.fl.delayTime.value=.004;
fx.flFb=ctx.createGain();fx.flFb.gain.value=.55;
fx.flWet=ctx.createGain();fx.flWet.gain.value=0;
fx.lfo=ctx.createOscillator();fx.lfo.frequency.value=.3;
fx.lfoAmt=ctx.createGain();fx.lfoAmt.gain.value=.0025;
fx.lfo.connect(fx.lfoAmt);fx.lfoAmt.connect(fx.fl.delayTime);fx.lfo.start();
fx.in.connect(fx.fl);fx.fl.connect(fx.flFb);fx.flFb.connect(fx.fl);fx.fl.connect(fx.flWet);fx.flWet.connect(master.in);

/* ---------- deck ---------- */
class Deck{
  constructor(id){
    this.id=id;this.buf=null;this.track=null;
    this.pos=0;this.t0=0;this.rate=1;this.bend=0;this.scratch=null;
    this.playing=false;this.src=null;this.cuePoint=0;this.hot=[null,null,null,null];
    this.loop=null;this.loopBeats=0;this.bpm=0;this.grid=0;this.previewing=false;
    const n=this.n={};
    n.trim=ctx.createGain();
    n.low=ctx.createBiquadFilter();n.low.type='lowshelf';n.low.frequency.value=200;
    n.mid=ctx.createBiquadFilter();n.mid.type='peaking';n.mid.frequency.value=1200;n.mid.Q.value=.8;
    n.high=ctx.createBiquadFilter();n.high.type='highshelf';n.high.frequency.value=3500;
    n.filt=ctx.createBiquadFilter();n.filt.type='allpass';
    n.chan=ctx.createGain();n.xf=ctx.createGain();n.send=ctx.createGain();n.send.gain.value=0;
    n.an=ctx.createAnalyser();n.an.fftSize=512;
    n.trim.connect(n.low);n.low.connect(n.mid);n.mid.connect(n.high);n.high.connect(n.filt);n.filt.connect(n.chan);n.chan.connect(n.xf);
    n.xf.connect(master.in);n.xf.connect(n.an);n.xf.connect(n.send);n.send.connect(fx.in);
  }
  emit(){}
  get eff(){return this.scratch!=null?this.scratch:this.rate*(1+this.bend)}
  get tempo(){return this.rate*(1+this.bend)}
  get dur(){return this.buf?this.buf.duration:0}
  getPos(){
    if(!this.playing)return this.pos;
    let p=this.pos+(ctx.currentTime-this.t0)*this.eff;const L=this.loop;
    if(L&&p>=L.e)p=L.s+((p-L.s)%(L.e-L.s));
    return clamp(p,0,this.dur);
  }
  rebase(){this.pos=this.getPos();this.t0=ctx.currentTime}
  applyRate(smooth){if(!this.src)return;const t=ctx.currentTime;
    if(smooth){this.src.playbackRate.cancelScheduledValues(t);this.src.playbackRate.setTargetAtTime(this.eff,t,.02)}
    else{this.src.playbackRate.cancelScheduledValues(t);this.src.playbackRate.setValueAtTime(this.eff,t)}}
  setRate(r){this.rebase();this.rate=r;this.applyRate();this.emit()}
  setBend(b){this.rebase();this.bend=b;this.applyRate()}
  setScratch(v){this.rebase();this.scratch=v;this.applyRate(true)}
  startSrc(){
    const s=ctx.createBufferSource();s.buffer=this.buf;s.playbackRate.value=this.eff;
    if(this.loop){s.loop=true;s.loopStart=this.loop.s;s.loopEnd=this.loop.e}
    s.connect(this.n.trim);
    s.onended=()=>{if(this.src===s){this.src=null;this.playing=false;this.pos=this.dur;this.emit()}};
    this.src=s;this.t0=ctx.currentTime;s.start(0,clamp(this.pos,0,Math.max(0,this.dur-.001)));
  }
  stopSrc(){const s=this.src;if(s){s.onended=null;try{s.stop()}catch(e){}try{s.disconnect()}catch(e){}}this.src=null}
  load(track){
    this.stopSrc();this.playing=false;this.track=track;this.buf=track.buf;this.bpm=track.bpm;this.grid=track.grid||0;
    this.pos=0;this.cuePoint=0;this.hot=[null,null,null,null];this.loop=null;this.loopBeats=0;this.rate=1;this.bend=0;this.scratch=null;
    this.emit();
  }
  play(){
    if(!this.buf||this.playing)return;ctx.resume();
    if(this.pos>=this.dur-.05)this.pos=this.cuePoint;
    this.playing=true;this.startSrc();this.emit();
  }
  pause(){if(!this.playing)return;this.pos=this.getPos();this.stopSrc();this.playing=false;this.emit()}
  toggle(){this.playing?this.pause():this.play()}
  seek(t){
    if(!this.buf)return;t=clamp(t,0,Math.max(0,this.dur-.01));
    if(this.loop&&(t<this.loop.s||t>=this.loop.e)){this.loop=null;this.loopBeats=0}
    if(this.playing){this.stopSrc();this.pos=t;this.startSrc()}else this.pos=t;
    this.emit();
  }
  cuePress(){
    if(!this.buf)return;
    if(this.playing){this.pause();this.seek(this.cuePoint)}
    else if(Math.abs(this.pos-this.cuePoint)<.05){this.previewing=true;this.play()}
    else{this.cuePoint=this.pos;this.emit()}
  }
  cueRelease(){if(this.previewing){this.previewing=false;this.pause();this.seek(this.cuePoint)}}
  hotPress(i,clear){
    if(!this.buf)return;
    if(clear){this.hot[i]=null;this.emit();return}
    if(this.hot[i]==null){this.hot[i]=this.getPos();this.emit()}
    else{this.seek(this.hot[i]);if(!this.playing)this.play()}
  }
  setLoop(beats){
    if(!this.bpm||!this.buf)return;
    if(this.loop&&this.loopBeats===beats){this.exitLoop();return}
    const p=this.getPos(),bl=60/this.bpm,len=bl*beats;
    let s=this.grid+Math.round((p-this.grid)/bl)*bl;if(s<0||s>=this.dur)s=p;
    if(s+len>this.dur)s=Math.max(0,this.dur-len);
    this.rebase();
    this.loop={s,e:s+len};this.loopBeats=beats;
    if(this.src){this.src.loop=true;this.src.loopStart=s;this.src.loopEnd=s+len}
    this.emit();
  }
  exitLoop(){
    if(!this.loop)return;this.rebase();this.loop=null;this.loopBeats=0;
    if(this.src)this.src.loop=false;this.emit();
  }
  sync(o){
    if(!this.bpm||!o||!o.bpm)return;
    let r=(o.bpm*o.rate)/this.bpm;if(r>1.45)r/=2;else if(r<.69)r*=2;
    r=clamp(r,1-RANGE,1+RANGE);this.setRate(r);
    if(this.playing&&o.playing){
      const bo=60/o.bpm,bt=60/this.bpm,n=x=>((x%1)+1)%1;
      let d=n((o.getPos()-o.grid)/bo)-n((this.getPos()-this.grid)/bt);d-=Math.round(d);
      this.seek(this.getPos()+d*bt);
    }
    this.emit();
  }
}
const decks={A:new Deck('A'),B:new Deck('B')};
function masterBpm(){
  for(const k of ['A','B']){const d=decks[k];if(d.playing&&d.bpm)return d.bpm*d.tempo}
  for(const k of ['A','B']){const d=decks[k];if(d.bpm)return d.bpm*d.rate}
  return 0;
}

/* ---------- track analysis ---------- */
function computePeaks(buf){
  const sr=buf.sampleRate,hop=Math.floor(sr/100),n=Math.ceil(buf.length/hop),out=new Float32Array(n*2);
  const ch=[];for(let i=0;i<buf.numberOfChannels;i++)ch.push(buf.getChannelData(i));
  let gmax=0;
  for(let i=0;i<n;i++){
    let mx=0,sum=0,cnt=0;const s=i*hop,e=Math.min(buf.length,s+hop);
    for(const d of ch)for(let j=s;j<e;j+=2){const v=Math.abs(d[j]);if(v>mx)mx=v;sum+=v;cnt++}
    out[i*2]=mx;out[i*2+1]=cnt?sum/cnt:0;if(mx>gmax)gmax=mx;
  }
  const ov=new Float32Array(600);
  for(let x=0;x<600;x++){const a=Math.floor(x/600*n),b=Math.max(a+1,Math.floor((x+1)/600*n));let m=0;for(let i=a;i<b&&i<n;i++)if(out[i*2]>m)m=out[i*2];ov[x]=gmax?m/gmax:0}
  return {peaks:out,peakMax:gmax||1,ov};
}
function detectBpm(buf){
  const sr=buf.sampleRate,hop=512,N=Math.floor(Math.min(buf.duration,90)*sr/hop);
  if(N<400)return {bpm:0,grid:0};
  const d0=buf.getChannelData(0),d1=buf.numberOfChannels>1?buf.getChannelData(1):d0,env=new Float32Array(N);
  let lp=0;
  for(let i=0;i<N;i++){let s=0;const a=i*hop;for(let j=0;j<hop;j+=2){lp+=((d0[a+j]+d1[a+j])*.5-lp)*.1;s+=lp*lp}env[i]=Math.sqrt(s/(hop/2))}
  const on=new Float32Array(N);for(let i=1;i<N;i++)on[i]=Math.max(0,env[i]-env[i-1]);
  const fps=sr/hop,lmin=Math.floor(fps*60/180),lmax=Math.ceil(fps*60/70);
  const sc=new Float64Array(lmax+2);let best=lmin,bs=0;
  for(let L=lmin;L<=lmax+1;L++){let s=0;for(let i=0;i+L<N;i++)s+=on[i]*on[i+L];sc[L]=s;if(L<=lmax&&s>bs){bs=s;best=L}}
  if(bs<=0)return {bpm:0,grid:0};
  let Lr=best;const a=sc[best-1]||0,b=sc[best],c=sc[best+1]||0,den=a-2*b+c;if(den<0)Lr=best+.5*(a-c)/den;
  let bpm=60*fps/Lr;while(bpm<85)bpm*=2;while(bpm>175)bpm/=2;
  const P=fps*60/bpm;let bk=0,bks=-1;
  for(let k=0;k<P;k++){let s=0;for(let m=0;k+m*P<N;m++)s+=on[Math.round(k+m*P)]||0;if(s>bks){bks=s;bk=k}}
  return {bpm:Math.round(bpm*10)/10,grid:bk/fps};
}

/* ---------- tracks ---------- */
const tracks=[];
function makeTrack(title,buf,o={}){
  const p=computePeaks(buf);
  const t={id:tracks.length+1,title,buf,dur:buf.duration,peaks:p.peaks,peakMax:p.peakMax,ov:p.ov,bpm:o.bpm||0,grid:o.grid||0,key:o.key||'—',demo:!!o.demo};
  if(!t.bpm){const r=detectBpm(buf);t.bpm=r.bpm;t.grid=r.grid}
  tracks.push(t);return t;
}
async function importFile(file){
  const ab=await file.arrayBuffer();
  const buf=await new Promise((res,rej)=>ctx.decodeAudioData(ab,res,rej));
  return makeTrack(file.name.replace(/\.[^.]+$/,''),buf,{});
}

/* ---------- drum kit and synthesised demo tracks ---------- */
function drumKit(c,dest,noise){
  const burst=(t,type,freq,q,v,len,tail)=>{const s=c.createBufferSource(),f=c.createBiquadFilter(),g=c.createGain();
    s.buffer=noise;f.type=type;f.frequency.value=freq;f.Q.value=q;
    g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v,t+.002);g.gain.exponentialRampToValueAtTime(.001,t+len);
    s.connect(f);f.connect(g);g.connect(dest);s.start(t,Math.random()*.5,len+(tail||.02))};
  return {
    kick(t,v=1){const o=c.createOscillator(),g=c.createGain();
      o.frequency.setValueAtTime(165,t);o.frequency.exponentialRampToValueAtTime(48,t+.11);
      g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v,t+.004);g.gain.exponentialRampToValueAtTime(.001,t+.38);
      o.connect(g);g.connect(dest);o.start(t);o.stop(t+.4)},
    hat(t,v=.3,len=.08){burst(t,'highpass',7500,.7,v,len)},
    clap(t){for(let k=0;k<4;k++)burst(t+k*.011,'bandpass',1500,.8,.5,k<3?.012:.17,.05)},
    snare(t){burst(t,'bandpass',1900,.6,.6,.2);const o=c.createOscillator(),g=c.createGain();
      o.type='triangle';o.frequency.setValueAtTime(220,t);o.frequency.exponentialRampToValueAtTime(150,t+.1);
      g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.5,t+.003);g.gain.exponentialRampToValueAtTime(.001,t+.14);
      o.connect(g);g.connect(dest);o.start(t);o.stop(t+.16)}
  };
}
function noiseBuffer(c){const sr=c.sampleRate,b=c.createBuffer(1,sr,sr),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;return b}

const DEMOS=[
  {title:'Neon Drive',key:'A min',bpm:124,bars:20,root:55,brk:[12,14],ghost:true,prog:[0,-4,-2,-5],
   bass:[0,null,12,null,0,null,0,12,null,0,null,12,0,null,7,null],
   arp:[12,null,19,null,15,null,19,null,12,null,19,24,null,15,null,19]},
  {title:'Midnight Circuit',key:'D min',bpm:128,bars:20,root:36.71,brk:[12,14],ghost:false,prog:[0,-2,-4,-7],
   bass:[0,0,null,0,12,null,0,null,0,0,null,12,0,null,10,null],
   arp:[null,12,null,15,null,19,null,15,12,null,15,null,19,null,22,null]},
  {title:'Glass Pulse',key:'F min',bpm:118,bars:20,root:43.65,brk:[12,14],ghost:true,prog:[0,3,-2,-4],
   bass:[0,null,null,7,null,null,0,null,null,12,null,null,7,null,5,null],
   arp:[12,null,15,null,19,null,15,null,12,null,15,null,19,null,24,null]},
  {title:'Rush Hour',key:'G min',bpm:132,bars:20,root:49,brk:[12,14],ghost:false,prog:[0,-2,-5,-7],
   bass:[0,null,0,null,12,null,0,null,0,null,0,12,null,0,null,7],
   arp:[19,null,15,null,12,null,15,null,19,null,22,null,19,null,15,null]}
];
async function renderDemo(sp){
  const sr=32000,step=60/sp.bpm/4,steps=sp.bars*16,dur=steps*step+1.5;
  const oc=new OfflineAudioContext(2,Math.ceil(sr*dur),sr),noise=noiseBuffer(oc);
  const out=oc.createGain();out.gain.value=.85;out.connect(oc.destination);
  out.gain.setValueAtTime(.85,(steps-32)*step);out.gain.linearRampToValueAtTime(0,steps*step);
  const mus=oc.createGain();mus.connect(out);
  const dl=oc.createDelay(1),dfb=oc.createGain(),dlp=oc.createBiquadFilter(),dw=oc.createGain();
  dl.delayTime.value=step*3;dfb.gain.value=.36;dlp.type='lowpass';dlp.frequency.value=2600;dw.gain.value=.4;
  dl.connect(dlp);dlp.connect(dfb);dfb.connect(dl);dlp.connect(dw);dw.connect(mus);
  const kit=drumKit(oc,out,noise);
  const note=(semi,oct)=>sp.root*oct*Math.pow(2,semi/12);
  const prog=bar=>sp.prog[Math.floor(bar/4)%sp.prog.length];
  const bass=(t,f,len)=>{const o=oc.createOscillator(),lp=oc.createBiquadFilter(),g=oc.createGain();
    o.type='sawtooth';o.frequency.value=f;lp.type='lowpass';lp.Q.value=5;
    lp.frequency.setValueAtTime(950,t);lp.frequency.exponentialRampToValueAtTime(170,t+len);
    g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.5,t+.006);g.gain.setValueAtTime(.5,t+len*.7);g.gain.exponentialRampToValueAtTime(.001,t+len);
    o.connect(lp);lp.connect(g);g.connect(mus);o.start(t);o.stop(t+len+.02)};
  const pluck=(t,f,len,v)=>{const lp=oc.createBiquadFilter(),g=oc.createGain();
    lp.type='lowpass';lp.Q.value=3;lp.frequency.setValueAtTime(3600,t);lp.frequency.exponentialRampToValueAtTime(700,t+len);
    g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v,t+.004);g.gain.exponentialRampToValueAtTime(.001,t+len);
    [['square',0],['sawtooth',8]].forEach(([ty,dt])=>{const o=oc.createOscillator();o.type=ty;o.frequency.value=f;o.detune.value=dt;o.connect(lp);o.start(t);o.stop(t+len+.02)});
    lp.connect(g);g.connect(mus);g.connect(dl)};
  const pad=(t,fs,len)=>{const lp=oc.createBiquadFilter(),g=oc.createGain();
    lp.type='lowpass';lp.frequency.value=1300;
    g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(.06,t+len*.35);g.gain.linearRampToValueAtTime(.0001,t+len);
    fs.forEach(f=>[-9,9].forEach(dt=>{const o=oc.createOscillator();o.type='sawtooth';o.frequency.value=f;o.detune.value=dt;o.connect(lp);o.start(t);o.stop(t+len+.05)}));
    lp.connect(g);g.connect(mus)};
  const riser=(t,len)=>{const s=oc.createBufferSource(),f=oc.createBiquadFilter(),g=oc.createGain();
    s.buffer=noise;s.loop=true;f.type='bandpass';f.Q.value=1.2;
    f.frequency.setValueAtTime(400,t);f.frequency.exponentialRampToValueAtTime(7000,t+len);
    g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.3,t+len);g.gain.setValueAtTime(.0001,t+len+.01);
    s.connect(f);f.connect(g);g.connect(out);s.start(t);s.stop(t+len+.05)};
  for(let s=0;s<steps;s++){
    const t=s*step,bar=Math.floor(s/16),st=s%16,brk=bar>=sp.brk[0]&&bar<sp.brk[1];
    if(!brk&&st%4===0){kit.kick(t);mus.gain.setValueAtTime(.3,t);mus.gain.linearRampToValueAtTime(1,t+step*3)}
    if(bar>=2&&!brk){
      if(st%4===2)kit.hat(t,.28,.09);else if(sp.ghost&&st%2===1)kit.hat(t,.09,.04);
      if(st===14&&bar%4===3)kit.hat(t,.3,.25);
    }
    if(!brk&&bar>=3&&(st===4||st===12))kit.clap(t);
    if(bar>=4&&!brk){const n=sp.bass[st];if(n!=null)bass(t,note(n+prog(bar),2),step*.9)}
    if(bar>=8){const n=sp.arp[st];if(n!=null)pluck(t,note(n+prog(bar),4),step*1.7,.11)}
    if(st===0&&bar%2===0&&bar>=6)pad(t,[0,3,7].map(x=>note(x+prog(bar),4)),step*32);
    if(brk&&bar===sp.brk[0]&&st===0)riser(t,(sp.brk[1]-sp.brk[0])*16*step);
  }
  return oc.startRendering();
}
/* ---------- controls ---------- */
function mkKnob(el,o){
  el.classList.add('knob');el.tabIndex=0;el.setAttribute('role','slider');el.setAttribute('aria-label',o.label);
  el.innerHTML='<div class="k-ring"></div><div class="k-cap"><i></i></div><span class="k-l">'+o.label+'</span>';
  const ring=el.children[0],cap=el.children[1],def=o.def==null?.5:o.def;let v=def,sy=0,sv=0,drag=false;
  const draw=()=>{
    const deg=v*270,m=135;let g;
    if(o.bipolar){g=v>=.5?`var(--k-off) 0deg ${m}deg,var(--k-on) ${m}deg ${deg}deg,var(--k-off) ${deg}deg 270deg`
                        :`var(--k-off) 0deg ${deg}deg,var(--k-on) ${deg}deg ${m}deg,var(--k-off) ${m}deg 270deg`}
    else g=`var(--k-on) 0deg ${deg}deg,var(--k-off) ${deg}deg 270deg`;
    ring.style.background=`conic-gradient(from -135deg,${g},transparent 270deg 360deg)`;
    cap.style.transform=`rotate(${deg-135}deg)`;el.setAttribute('aria-valuenow',v.toFixed(2));
  };
  const set=(nv,silent)=>{v=clamp(nv,0,1);draw();if(!silent&&o.onChange)o.onChange(v)};
  el.addEventListener('pointerdown',e=>{el.setPointerCapture(e.pointerId);sy=e.clientY;sv=v;drag=true;e.preventDefault()});
  el.addEventListener('pointermove',e=>{if(drag)set(sv+(sy-e.clientY)/(e.shiftKey?600:160))});
  const end=()=>{drag=false};el.addEventListener('pointerup',end);el.addEventListener('pointercancel',end);
  el.addEventListener('dblclick',()=>set(def));
  el.addEventListener('wheel',e=>{e.preventDefault();set(v-Math.sign(e.deltaY)*.03)},{passive:false});
  el.addEventListener('keydown',e=>{
    if(e.key==='ArrowUp'||e.key==='ArrowRight'){set(v+.03);e.preventDefault()}
    else if(e.key==='ArrowDown'||e.key==='ArrowLeft'){set(v-.03);e.preventDefault()}});
  el.set=set;el.get=()=>v;set(v);return el;
}
function mkSlider(el,o){
  el.classList.add('slider',o.vertical?'v':'h');el.tabIndex=0;el.setAttribute('role','slider');el.setAttribute('aria-label',o.label||'');
  el.innerHTML='<div class="s-rail"></div><div class="s-thumb"></div>';
  const th=el.children[1],def=o.def==null?.5:o.def;let v=def,drag=false;
  const draw=()=>{const p=`calc((100% - 22px) * ${v})`;if(o.vertical)th.style.bottom=p;else th.style.left=p;el.setAttribute('aria-valuenow',v.toFixed(2))};
  const set=(nv,silent)=>{v=clamp(nv,0,1);draw();if(!silent&&o.onChange)o.onChange(v)};
  const fromEvent=e=>{const r=el.getBoundingClientRect();
    set(o.vertical?1-(e.clientY-r.top-11)/(r.height-22):(e.clientX-r.left-11)/(r.width-22))};
  el.addEventListener('pointerdown',e=>{el.setPointerCapture(e.pointerId);drag=true;fromEvent(e);e.preventDefault()});
  el.addEventListener('pointermove',e=>{if(drag)fromEvent(e)});
  const end=()=>{drag=false};el.addEventListener('pointerup',end);el.addEventListener('pointercancel',end);
  el.addEventListener('dblclick',()=>set(def));
  el.addEventListener('keydown',e=>{
    if(e.key==='ArrowUp'||e.key==='ArrowRight'){set(v+.03);e.preventDefault()}
    else if(e.key==='ArrowDown'||e.key==='ArrowLeft'){set(v-.03);e.preventDefault()}});
  el.set=set;el.get=()=>v;el.dragging=()=>drag;set(v);return el;
}
function holdButton(btn,down,up){
  btn.addEventListener('pointerdown',e=>{btn.setPointerCapture(e.pointerId);e.preventDefault();down(e)});
  const end=e=>{up&&up(e)};btn.addEventListener('pointerup',end);btn.addEventListener('pointercancel',end);
}

/* ---------- meters ---------- */
const meterBuf=new Float32Array(512);
function peakOf(an){an.getFloatTimeDomainData(meterBuf);let m=0;for(let i=0;i<meterBuf.length;i++){const a=Math.abs(meterBuf[i]);if(a>m)m=a}return m}
function ledColor(f){return f>.88?css('--crit'):f>.7?css('--warn'):css('--ok')}
const _css={};function css(n){return _css[n]||(_css[n]=getComputedStyle(document.documentElement).getPropertyValue(n).trim())}
function drawVMeter(c,level){
  const g=c.getContext('2d'),W=c.width,H=c.height,n=20,gap=2*dpr,h=(H-gap*(n-1))/n,lit=Math.round(clamp(level,0,1)*n);
  g.clearRect(0,0,W,H);
  for(let i=0;i<n;i++){const y=H-(i+1)*h-i*gap;g.fillStyle=i<lit?ledColor((i+1)/n):'#1a212c';g.fillRect(0,y,W,h)}
}
function drawHMeter(c,l,r){
  const g=c.getContext('2d'),W=c.width,H=c.height,n=26,gap=2*dpr,w=(W-gap*(n-1))/n,hh=(H-gap)/2;
  g.clearRect(0,0,W,H);
  [l,r].forEach((lv,row)=>{const lit=Math.round(clamp(lv,0,1)*n);
    for(let i=0;i<n;i++){g.fillStyle=i<lit?ledColor((i+1)/n):'#1a212c';g.fillRect(i*(w+gap),row*(hh+gap),w,hh)}});
}

/* ---------- deck UI ---------- */
const ICON_PLAY='<svg viewBox="0 0 24 24"><path d="M7 4.5v15l12-7.5z"/></svg>';
const ICON_PAUSE='<svg viewBox="0 0 24 24"><path d="M6 4.5h4v15H6zM14 4.5h4v15h-4z"/></svg>';
const ui={};
function buildDeck(id){
  const d=decks[id],slot=$('#deck'+id);
  slot.innerHTML=`<section class="deck" aria-label="Platine ${id}">
    <div class="dhead"><div class="dtag">${id}</div>
      <div class="meta"><div class="title">Aucun morceau</div><div class="sub"><b class="bpm">--</b> BPM · <span class="time">0:00</span> / <span class="dur">0:00</span> · <span class="key">—</span></div></div>
      <label class="btn sm filebtn">Charger<input class="load" type="file" accept="audio/*" multiple aria-label="Charger un morceau sur la platine ${id}"></label></div>
    <canvas class="wave"></canvas><canvas class="over"></canvas>
    <div class="main">
      <div class="jog" aria-label="Plateau, glisser pour scratcher"><div class="plat"><i></i></div><div class="hub">${id}</div></div>
      <div class="side">
        <div class="transport"><button class="btn cue" type="button">Cue</button><button class="btn play" type="button" aria-label="Lecture">${ICON_PLAY}</button><button class="btn sync" type="button">Sync</button></div>
        <div class="hot">${[1,2,3,4].map(i=>`<button class="btn" type="button" title="Repère ${i} (clic droit : effacer)">${i}</button>`).join('')}</div>
        <div class="rowl"><span class="lbl">Boucle</span><div class="loops" style="flex:1">${[['1/2',.5],['1',1],['2',2],['4',4],['8',8]].map(([l,b])=>`<button class="btn sm" type="button" data-b="${b}">${l}</button>`).join('')}<button class="btn sm clr" type="button" title="Effacer les repères">Eff.</button></div></div>
        <div class="bends"><button class="btn sm bm" type="button">− Tempo</button><button class="btn sm pr" type="button">Reset</button><button class="btn sm bp" type="button">Tempo +</button></div>
      </div>
      <div class="pitch"><div class="pfader"></div><div class="pv">0.0%</div></div>
    </div></section>`;
  const q=s=>$(s,slot),U=ui[id]={d,root:q('.deck'),title:q('.title'),bpm:q('.bpm'),time:q('.time'),dur:q('.dur'),key:q('.key'),
    wave:q('.wave'),over:q('.over'),jog:q('.jog'),plat:q('.plat'),play:q('.play'),hot:$$('.hot .btn',slot),loops:$$('.loops [data-b]',slot),
    pv:q('.pv'),angle:0,color:id==='A'?css('--a'):css('--b')};
  U.pf=mkSlider(q('.pfader'),{vertical:true,def:.5,label:'Tempo platine '+id,onChange:v=>{d.setRate(1+(v-.5)*2*RANGE)}});
  q('.load').addEventListener('change',async e=>{const f=[...e.target.files];e.target.value='';await addFiles(f,id)});
  q('.play').onclick=()=>d.toggle();
  holdButton(q('.cue'),()=>d.cuePress(),()=>d.cueRelease());
  q('.sync').onclick=()=>d.sync(decks[id==='A'?'B':'A']);
  U.hot.forEach((b,i)=>{b.addEventListener('pointerdown',e=>{if(e.button===2)return;d.hotPress(i,e.shiftKey)});b.addEventListener('contextmenu',e=>{e.preventDefault();d.hotPress(i,true)})});
  U.loops.forEach(b=>b.onclick=()=>d.setLoop(+b.dataset.b));
  q('.clr').onclick=()=>{d.hot=[null,null,null,null];d.emit()};
  holdButton(q('.bm'),()=>d.setBend(-.07),()=>d.setBend(0));
  holdButton(q('.bp'),()=>d.setBend(.07),()=>d.setBend(0));
  q('.pr').onclick=()=>{U.pf.set(.5)};
  U.over.addEventListener('pointerdown',e=>{U.over.setPointerCapture(e.pointerId);U.seekDrag=true;ovSeek(U,e)});
  U.over.addEventListener('pointermove',e=>{if(U.seekDrag)ovSeek(U,e)});
  U.over.addEventListener('pointerup',()=>U.seekDrag=false);
  // jog: scratch while playing, search while paused
  let lastA=0,lastT=0,vel=0;
  const ang=e=>{const r=U.jog.getBoundingClientRect();return Math.atan2(e.clientY-(r.top+r.height/2),e.clientX-(r.left+r.width/2))};
  U.jog.addEventListener('pointerdown',e=>{U.jog.setPointerCapture(e.pointerId);U.jog.classList.add('grab');U.jogDrag=true;lastA=ang(e);lastT=performance.now();vel=0;ctx.resume();if(d.playing)d.setScratch(.02);e.preventDefault()});
  U.jog.addEventListener('pointermove',e=>{
    if(!U.jogDrag)return;const a=ang(e),now=performance.now();let da=a-lastA;if(da>Math.PI)da-=2*Math.PI;if(da<-Math.PI)da+=2*Math.PI;
    const dt=Math.max(1,now-lastT)/1000;U.angle+=da*180/Math.PI;
    if(d.playing){vel=vel*.6+(da/dt/3.49)*.4;d.setScratch(clamp(vel,.02,4))}
    else if(d.buf)d.seek(d.pos+da*.2865);
    lastA=a;lastT=now});
  const jend=()=>{if(!U.jogDrag)return;U.jogDrag=false;U.jog.classList.remove('grab');if(d.scratch!=null)d.setScratch(null)};
  U.jog.addEventListener('pointerup',jend);U.jog.addEventListener('pointercancel',jend);
  // waveform drag: scratch while playing, scrub while paused
  let wx=0,wt=0,wv=0;U.wave.style.touchAction='none';U.wave.style.cursor='grab';
  U.wave.addEventListener('pointerdown',e=>{U.wave.setPointerCapture(e.pointerId);U.waveDrag=true;wx=e.clientX;wt=performance.now();wv=0;ctx.resume();if(d.playing)d.setScratch(.02);e.preventDefault()});
  U.wave.addEventListener('pointermove',e=>{
    if(!U.waveDrag)return;const now=performance.now(),dx=e.clientX-wx,dt=Math.max(1,now-wt)/1000,dtime=-dx*8/Math.max(1,U.wave.clientWidth);
    if(d.playing){wv=wv*.6+(dtime/dt)*.4;d.setScratch(clamp(wv,.02,4))}else if(d.buf)d.seek(d.pos+dtime);
    wx=e.clientX;wt=now});
  const wend=()=>{if(!U.waveDrag)return;U.waveDrag=false;if(d.scratch!=null)d.setScratch(null)};
  U.wave.addEventListener('pointerup',wend);U.wave.addEventListener('pointercancel',wend);
  // drag and drop of audio files
  const dz=U.root;
  dz.addEventListener('dragover',e=>{e.preventDefault();dz.classList.add('drop')});
  dz.addEventListener('dragleave',()=>dz.classList.remove('drop'));
  dz.addEventListener('drop',async e=>{e.preventDefault();dz.classList.remove('drop');const f=[...e.dataTransfer.files].filter(x=>/^audio\//.test(x.type)||/\.(mp3|wav|m4a|ogg|flac|aac)$/i.test(x.name));await addFiles(f,id)});
  d.emit=()=>refreshDeck(id);refreshDeck(id);
}
function ovSeek(U,e){const d=U.d;if(!d.buf)return;const r=U.over.getBoundingClientRect();d.seek((e.clientX-r.left)/r.width*d.dur)}
function refreshDeck(id){
  const U=ui[id],d=U.d;
  U.title.textContent=d.track?d.track.title:'Aucun morceau';
  U.bpm.textContent=d.bpm?(d.bpm*d.rate).toFixed(1):'--';
  U.dur.textContent=fmtTime(d.dur);U.key.textContent=d.track?d.track.key:'—';
  U.play.innerHTML=d.playing?ICON_PAUSE:ICON_PLAY;U.play.classList.toggle('on',d.playing);
  U.hot.forEach((b,i)=>b.classList.toggle('set',d.hot[i]!=null));
  U.loops.forEach(b=>b.classList.toggle('on',!!d.loop&&+b.dataset.b===d.loopBeats));
  const pct=(d.rate-1)*100;U.pv.textContent=(pct>=0?'+':'')+pct.toFixed(1)+'%';
  if(!U.pf.dragging())U.pf.set((d.rate-1)/(2*RANGE)+.5,true);
  if(typeof refreshLib==='function')refreshLib();
}

/* ---------- drawing ---------- */
function fitCanvas(c){const w=Math.round(c.clientWidth*dpr),h=Math.round(c.clientHeight*dpr);if(c.width!==w||c.height!==h){c.width=w;c.height=h}}
function drawWave(U){
  const d=U.d,c=U.wave;fitCanvas(c);const g=c.getContext('2d'),W=c.width,H=c.height,mid=H/2;
  g.clearRect(0,0,W,H);
  if(!d.track){g.fillStyle='#4a5568';g.font=`${13*dpr}px Inter,sans-serif`;g.textAlign='center';g.fillText(libState.demoBusy?'Préparation du morceau de démo…':'Touchez « Charger » pour ajouter un morceau',W/2,mid+4*dpr);return}
  const pk=d.track.peaks,sc=1/d.track.peakMax,pos=d.getPos(),win=8,pps=W/win,t0=pos-win/2,t1=pos+win/2,n=pk.length/2;
  if(d.bpm){const bl=60/d.bpm;let k=Math.ceil((t0-d.grid)/bl);
    for(let t=d.grid+k*bl;t<t1;t+=bl,k++){const x=Math.round((t-t0)*pps),bar=((k%4)+4)%4===0;g.fillStyle=bar?'rgba(255,255,255,.34)':'rgba(255,255,255,.12)';g.fillRect(x,0,(bar?2:1)*dpr,H)}}
  if(d.loop){const x1=(d.loop.s-t0)*pps,x2=(d.loop.e-t0)*pps;g.fillStyle='rgba(111,213,138,.2)';g.fillRect(x1,0,x2-x1,H);g.fillStyle='rgba(111,213,138,.7)';g.fillRect(x1,0,2*dpr,H);g.fillRect(x2-2*dpr,0,2*dpr,H)}
  const step=2*dpr;g.fillStyle=U.color;
  for(let x=0;x<W;x+=step){
    const i=Math.floor((pos+(x+step/2-W/2)/pps)*100);if(i<0||i>=n)continue;
    const mx=Math.min(1,pk[i*2]*sc)*mid*.94,av=Math.min(mx,pk[i*2+1]*sc*1.7*mid*.94);
    g.globalAlpha=x<W/2?.38:.85;g.fillRect(x,mid-mx,step-dpr,mx*2);
    g.globalAlpha=x<W/2?.5:1;g.fillStyle='rgba(255,255,255,.55)';g.fillRect(x,mid-av,step-dpr,av*2);g.fillStyle=U.color;
  }
  g.globalAlpha=1;
  const flag=(t,col,label)=>{const x=(t-t0)*pps;if(x<-20||x>W+20)return;g.fillStyle=col;g.fillRect(x,0,2*dpr,H);g.fillRect(x,0,14*dpr,12*dpr);g.fillStyle='#0a0d12';g.font=`700 ${10*dpr}px Inter,sans-serif`;g.textAlign='left';g.fillText(label,x+4*dpr,10*dpr)};
  flag(d.cuePoint,css('--b'),'C');
  const hc=[css('--crit'),css('--warn'),css('--ok'),'#6aa8ff'];d.hot.forEach((t,i)=>{if(t!=null)flag(t,hc[i],String(i+1))});
  g.fillStyle='#fff';g.fillRect(W/2-dpr,0,2*dpr,H);
}
function drawOver(U){
  const d=U.d,c=U.over;fitCanvas(c);const g=c.getContext('2d'),W=c.width,H=c.height;g.clearRect(0,0,W,H);
  if(!d.track)return;
  const ov=d.track.ov,bw=2*dpr,px=d.getPos()/d.dur*W;
  for(let x=0;x<W;x+=bw){const h=Math.max(1,ov[Math.min(599,Math.floor(x/W*600))]*H*.9);g.fillStyle=U.color;g.globalAlpha=x<px?.9:.35;g.fillRect(x,(H-h)/2,bw-dpr,h)}
  g.globalAlpha=1;
  if(d.loop){g.fillStyle='rgba(111,213,138,.3)';g.fillRect(d.loop.s/d.dur*W,0,(d.loop.e-d.loop.s)/d.dur*W,H)}
  const hc=[css('--crit'),css('--warn'),css('--ok'),'#6aa8ff'];
  d.hot.forEach((t,i)=>{if(t!=null){g.fillStyle=hc[i];g.fillRect(t/d.dur*W,0,2*dpr,H)}});
  g.fillStyle='#fff';g.fillRect(px-dpr,0,2*dpr,H);
}

/* ---------- mixer ---------- */
const EQ_DB=v=>v<.5?(v/.5)*50-50:((v-.5)/.5)*6;
function buildStrip(id){
  const d=decks[id],el=$('#strip'+id);
  el.innerHTML='<div class="knobs"></div><div class="fad"><canvas width="28" height="340"></canvas><div></div></div>';
  const kn=$('.knobs',el),mk=(lab,o)=>{const k=document.createElement('div');kn.appendChild(k);return mkKnob(k,Object.assign({label:lab},o))};
  mk('GAIN',{def:.5,onChange:v=>d.n.trim.gain.value=v*2});
  mk('HAUT',{def:.5,bipolar:true,onChange:v=>d.n.high.gain.value=EQ_DB(v)});
  mk('MED',{def:.5,bipolar:true,onChange:v=>d.n.mid.gain.value=EQ_DB(v)});
  mk('BAS',{def:.5,bipolar:true,onChange:v=>d.n.low.gain.value=EQ_DB(v)});
  mk('FILTRE',{def:.5,bipolar:true,onChange:v=>{
    const f=d.n.filt,t=ctx.currentTime;
    if(Math.abs(v-.5)<.025){f.type='allpass';return}
    if(v<.5){f.type='lowpass';f.Q.value=3;f.frequency.setTargetAtTime(80*Math.pow(250,v/.5),t,.01)}
    else{f.type='highpass';f.Q.value=3;f.frequency.setTargetAtTime(20*Math.pow(400,(v-.5)/.5),t,.01)}}});
  ui[id].meter=$('canvas',el);
  mkSlider($('.fad > div',el),{vertical:true,def:1,label:'Volume voie '+id,onChange:v=>d.n.chan.gain.value=v*v});
  $('.fad > div',el).set(1);
}
let xfCurve='soft',xfVal=.5;
function applyXf(){
  const x=xfVal;let a,b;
  if(xfCurve==='soft'){a=Math.cos(x*Math.PI/2);b=Math.cos((1-x)*Math.PI/2)}else{a=Math.min(1,2*(1-x));b=Math.min(1,2*x)}
  decks.A.n.xf.gain.setTargetAtTime(a,ctx.currentTime,.008);decks.B.n.xf.gain.setTargetAtTime(b,ctx.currentTime,.008);
}
let xfEl,fadeRaf=0;
function buildCrossfader(){
  xfEl=mkSlider($('#xfader'),{vertical:false,def:.5,label:'Crossfader',onChange:v=>{xfVal=v;applyXf()}});
  $('#curveBtn').onclick=e=>{xfCurve=xfCurve==='soft'?'sharp':'soft';e.currentTarget.textContent='Courbe : '+(xfCurve==='soft'?'douce':'coupée');applyXf()};
  $('#fadeBtn').onclick=()=>{
    cancelAnimationFrame(fadeRaf);const from=xfVal,to=from<.5?1:0,t0=performance.now(),D=8000;
    const tick=now=>{const p=clamp((now-t0)/D,0,1),e=p<.5?2*p*p:1-Math.pow(-2*p+2,2)/2;xfEl.set(from+(to-from)*e);if(p<1)fadeRaf=requestAnimationFrame(tick)};
    fadeRaf=requestAnimationFrame(tick);
    if(!decks.A.playing&&!decks.B.playing){}
  };
  applyXf();
}
/* ---------- effects ---------- */
let echoDiv=.75;
function updateEcho(){const b=masterBpm()||120;fx.delay.delayTime.setTargetAtTime(clamp(60/b*echoDiv*(echoDiv>=1?1:1),.02,1.9),ctx.currentTime,.05)}
function buildFx(){
  const box=$('#fxKnobs'),mk=(lab,o)=>{const k=document.createElement('div');box.appendChild(k);return mkKnob(k,Object.assign({label:lab},o))};
  mk('ÉCHO',{def:0,onChange:v=>fx.echoWet.gain.setTargetAtTime(v*.9,ctx.currentTime,.02)});
  mk('RETOUR',{def:.45,onChange:v=>fx.fb.gain.setTargetAtTime(v*.85,ctx.currentTime,.02)});
  mk('REVERB',{def:0,onChange:v=>fx.revWet.gain.setTargetAtTime(v*1.2,ctx.currentTime,.02)});
  mk('FLANGER',{def:0,onChange:v=>fx.flWet.gain.setTargetAtTime(v*.8,ctx.currentTime,.02)});
  mk('VITESSE',{def:.3,onChange:v=>fx.lfo.frequency.setTargetAtTime(.05+v*v*4,ctx.currentTime,.02)});
  const dv=$('#echoDiv');
  [['1/4',.25],['1/2',.5],['3/4',.75],['1',1]].forEach(([l,v])=>{
    const b=document.createElement('button');b.type='button';b.className='btn sm'+(v===echoDiv?' on':'');b.textContent=l;
    b.onclick=()=>{echoDiv=v;$$('.btn',dv).forEach(x=>x.classList.toggle('on',x===b));updateEcho()};dv.appendChild(b)});
  [['A','#sendA'],['B','#sendB']].forEach(([id,sel])=>{const b=$(sel);
    b.onclick=()=>{const on=!b.classList.contains('on');b.classList.toggle('on',on);decks[id].n.send.gain.setTargetAtTime(on?1:0,ctx.currentTime,.02)}});
  setInterval(updateEcho,500);
}

/* ---------- sampler pads ---------- */
const padBus=ctx.createGain();padBus.gain.value=.8;padBus.connect(master.in);
let rtNoise=null,rtKit=null;
function kit(){if(!rtNoise){rtNoise=noiseBuffer(ctx);rtKit=drumKit(ctx,padBus,rtNoise)}return rtKit}
function osc(type,f,t,len,v,fn){const o=ctx.createOscillator(),g=ctx.createGain();o.type=type;o.frequency.setValueAtTime(f,t);if(fn)fn(o,t);
  g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v,t+.01);g.gain.setValueAtTime(v,t+len*.7);g.gain.exponentialRampToValueAtTime(.001,t+len);
  o.connect(g);g.connect(padBus);o.start(t);o.stop(t+len+.03)}
const PADS=[
  {n:'KICK',k:'Z',h:12,f:t=>kit().kick(t,1)},
  {n:'SNARE',k:'X',h:38,f:t=>kit().snare(t)},
  {n:'HAT',k:'C',h:150,f:t=>kit().hat(t,.4,.1)},
  {n:'CLAP',k:'V',h:190,f:t=>kit().clap(t)},
  {n:'KLAXON',k:'B',h:280,f:t=>{[392,466,587].forEach((f,i)=>osc('square',f,t,.9,.12,(o,tt)=>{o.detune.setValueAtTime(i*6,tt)}))}},
  {n:'SIRÈNE',k:'N',h:330,f:t=>osc('sawtooth',500,t,1.4,.1,(o,tt)=>{o.frequency.linearRampToValueAtTime(1500,tt+.7);o.frequency.linearRampToValueAtTime(500,tt+1.4)})},
  {n:'LASER',k:'M',h:225,f:t=>osc('sine',2600,t,.3,.3,(o,tt)=>{o.frequency.exponentialRampToValueAtTime(110,tt+.28)})},
  {n:'RISER',k:',',h:60,f:t=>{kit();const s=ctx.createBufferSource(),fl=ctx.createBiquadFilter(),g=ctx.createGain();
    s.buffer=rtNoise;s.loop=true;fl.type='bandpass';fl.Q.value=1.2;
    fl.frequency.setValueAtTime(300,t);fl.frequency.exponentialRampToValueAtTime(7000,t+2.5);
    g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.35,t+2.5);g.gain.linearRampToValueAtTime(.0001,t+2.7);
    s.connect(fl);fl.connect(g);g.connect(padBus);s.start(t);s.stop(t+2.8)}}
];
const padEls=[];
function hitPad(i){ctx.resume();PADS[i].f(ctx.currentTime+.005);const b=padEls[i];b.classList.add('hit');setTimeout(()=>b.classList.remove('hit'),110)}
function buildPads(){
  const box=$('#pads');
  PADS.forEach((p,i)=>{const b=document.createElement('button');b.type='button';b.className='pad';b.style.setProperty('--h',p.h);
    b.innerHTML=`${p.n}<small>${p.k}</small>`;b.addEventListener('pointerdown',e=>{e.preventDefault();hitPad(i)});box.appendChild(b);padEls.push(b)});
  const k=document.createElement('div');$('#padVol').appendChild(k);
  mkKnob(k,{label:'VOL',def:.8,onChange:v=>padBus.gain.value=v});
  k.style.height='60px';
}

/* ---------- library ---------- */
const libState={busy:[]};
function refreshLib(){
  const box=$('#lib');if(!box)return;box.innerHTML='';
  tracks.forEach(t=>{
    const r=document.createElement('div'),inA=decks.A.track===t,inB=decks.B.track===t;r.className='row';
    r.innerHTML=`<span class="t" title="${t.title.replace(/"/g,'&quot;')}">${t.title.replace(/</g,'&lt;')}</span><span class="m k">${t.key}</span><span class="m">${t.bpm?t.bpm.toFixed(1):'--'}</span><span class="m d">${fmtTime(t.dur)}</span>
      <button class="btn sm la${inA?' on':''}" type="button">A</button><button class="btn sm lb${inB?' on':''}" type="button">B</button>`;
    $('.la',r).onclick=()=>decks.A.load(t);$('.lb',r).onclick=()=>decks.B.load(t);box.appendChild(r);
  });
  libState.busy.forEach(msg=>{const r=document.createElement('div');r.className='row busy';r.innerHTML=`<span class="t">${msg}</span><span></span><span></span><span></span><span></span><span></span>`;box.appendChild(r)});
}
async function addFiles(files,toDeck){
  files=files.filter(f=>/^audio\//.test(f.type)||/\.(mp3|wav|m4a|ogg|oga|flac|aac|opus|webm)$/i.test(f.name));
  let first=true;
  for(const f of files){
    const safe=f.name.replace(/</g,'&lt;'),msg='Analyse de '+safe+'…';libState.busy.push(msg);refreshLib();
    try{
      const t=await importFile(f);libState.busy=libState.busy.filter(x=>x!==msg);
      if(toDeck&&first){decks[toDeck].load(t)}else refreshLib();
      first=false;
    }catch(e){
      libState.busy=libState.busy.filter(x=>x!==msg);const err='Impossible de lire '+safe;libState.busy.push(err);refreshLib();
      setTimeout(()=>{libState.busy=libState.busy.filter(x=>x!==err);refreshLib()},4500);
    }
  }
}

/* ---------- animation loop ---------- */
const peakHold={A:0,B:0,L:0,R:0};
let lastFrame=performance.now();
function frame(now){
  const dt=Math.min(.1,(now-lastFrame)/1000);lastFrame=now;
  for(const id of ['A','B']){
    const U=ui[id],d=U.d,pos=d.getPos();
    U.time.textContent=fmtTime(pos);
    if(!U.jogDrag)U.angle+=d.playing?d.eff*200*dt:0;
    U.plat.style.transform=`rotate(${U.angle}deg)`;
    U.bpm.textContent=d.bpm?(d.bpm*d.tempo).toFixed(1):'--';
    drawWave(U);drawOver(U);
    const p=peakOf(d.n.an);peakHold[id]=Math.max(p,peakHold[id]-dt*1.4);fitCanvas(U.meter);drawVMeter(U.meter,Math.pow(peakHold[id],.6));
  }
  const l=peakOf(master.anL),r=peakOf(master.anR);peakHold.L=Math.max(l,peakHold.L-dt*1.4);peakHold.R=Math.max(r,peakHold.R-dt*1.4);
  drawHMeter($('#mmeter'),Math.pow(peakHold.L,.6),Math.pow(peakHold.R,.6));
  const mb=masterBpm();$('#mbpm').textContent=mb?mb.toFixed(1):'--';
  requestAnimationFrame(frame);
}

/* ---------- keyboard ---------- */
const downKeys=new Set();
document.addEventListener('keydown',e=>{
  if(e.repeat||e.metaKey||e.ctrlKey||e.altKey)return;
  const t=e.target;if(t&&t.closest&&t.closest('.knob,.slider,input,button.btn:focus-visible'))if(e.code.startsWith('Arrow')||e.code==='Space')return;
  const c=e.code,A=decks.A,B=decks.B;let used=true;
  if(c==='KeyQ')A.toggle();else if(c==='KeyW'){A.cuePress();downKeys.add(c)}
  else if(c==='KeyP')B.toggle();else if(c==='KeyO'){B.cuePress();downKeys.add(c)}
  else if(/^Digit[1-4]$/.test(c))A.hotPress(+c.slice(5)-1,e.shiftKey);
  else if(c==='Digit7')B.hotPress(0,e.shiftKey);else if(c==='Digit8')B.hotPress(1,e.shiftKey);
  else if(c==='Digit9')B.hotPress(2,e.shiftKey);else if(c==='Digit0')B.hotPress(3,e.shiftKey);
  else if(c==='ArrowLeft')xfEl.set(xfEl.get()-.05);else if(c==='ArrowRight')xfEl.set(xfEl.get()+.05);
  else{const i=PADS.findIndex(p=>'Key'+p.k===c||(p.k===','&&c==='Comma'));if(i>=0)hitPad(i);else used=false}
  if(used)e.preventDefault();
});
document.addEventListener('keyup',e=>{
  if(e.code==='KeyW'&&downKeys.delete('KeyW'))decks.A.cueRelease();
  if(e.code==='KeyO'&&downKeys.delete('KeyO'))decks.B.cueRelease();
});

/* ---------- start ---------- */
function init(){
  buildDeck('A');buildDeck('B');buildStrip('A');buildStrip('B');buildCrossfader();buildFx();buildPads();
  mkKnob($('#kMaster'),{label:'MASTER',def:.8,onChange:v=>master.vol.gain.setTargetAtTime(v,ctx.currentTime,.02)});
  const sb=$('#startBtn'),sync=()=>{sb.hidden=ctx.state==='running'};
  sb.onclick=()=>ctx.resume();ctx.onstatechange=sync;sync();
  document.addEventListener('pointerdown',()=>{if(ctx.state!=='running')ctx.resume()},{capture:true});
  $('#fileIn').addEventListener('change',async e=>{const f=[...e.target.files];e.target.value='';await addFiles(f,null)});
  const fs=$('#fsBtn');
  if(document.fullscreenEnabled&&matchMedia('(pointer:coarse)').matches){fs.hidden=false;fs.onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else{await document.documentElement.requestFullscreen();try{await screen.orientation.lock('landscape')}catch(e){}}}catch(e){}}}
  $('#rotOk').onclick=()=>$('#rotHint').classList.add('gone');
  refreshLib();requestAnimationFrame(frame);
  libState.demoBusy=true;
  (async()=>{
    for(let i=0;i<DEMOS.length;i++){
      const sp=DEMOS[i],msg='Génération de « '+sp.title+' »…';libState.busy.push(msg);refreshLib();
      await new Promise(r=>setTimeout(r,30));
      try{
        const buf=await renderDemo(sp),t=makeTrack(sp.title,buf,{bpm:sp.bpm,grid:0,key:sp.key,demo:true});
        libState.busy=libState.busy.filter(x=>x!==msg);
        if(i===0&&!decks.A.track)decks.A.load(t);else if(i===1&&!decks.B.track)decks.B.load(t);else refreshLib();
        if(i===1)libState.demoBusy=false;
      }catch(err){libState.busy=libState.busy.filter(x=>x!==msg);refreshLib()}
    }
    libState.demoBusy=false;
  })();
}
init();
