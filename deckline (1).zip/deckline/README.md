# Deckline

Table de mixage DJ à deux platines qui tourne dans le navigateur (Web Audio API). Aucun serveur, aucune dépendance, aucune compilation.

## Fonctions

- Deux platines : forme d'onde défilante, cue, 4 repères, boucles de ½ à 8 temps, fader de tempo (±16 %), Sync, scratch en faisant glisser la forme d'onde ou le plateau
- Mixeur : gain, EQ 3 bandes, filtre, vumètres, crossfader (deux courbes) et fondu automatique
- Effets : écho calé sur le tempo, reverb, flanger
- 8 pads de sons, jouables au clavier
- Bibliothèque : import de vos MP3, WAV, M4A, OGG (bouton ou glisser-déposer), détection du BPM
- 4 morceaux de démo générés au lancement

## Lancer en local

Ouvrez `index.html` dans Chrome, Edge, Firefox ou Safari. Si le navigateur bloque quelque chose en ouvrant le fichier directement, lancez un petit serveur :

```bash
python3 -m http.server 8000
# puis http://localhost:8000
```

## Publier sur GitHub Pages

1. Créez un dépôt sur GitHub et envoyez-y ces fichiers (`git push` sur la branche `main`).
2. Dans le dépôt : **Settings → Pages → Build and deployment → Source : GitHub Actions**.
3. Le workflow `.github/workflows/pages.yml` se lance à chaque push et publie le site. Son adresse apparaît dans l'onglet **Actions** puis dans **Settings → Pages**.

Il n'y a pas d'étape de compilation : le workflow copie simplement les fichiers statiques.

## Application Android (APK)

Le workflow `.github/workflows/android.yml` compile une vraie application Android avec Capacitor, directement sur GitHub. Rien à installer chez vous.

1. Envoyez le projet sur la branche `main` de votre dépôt.
2. Ouvrez l'onglet **Actions** : la tâche « Compiler l'APK Android » se lance toute seule (5 à 10 minutes la première fois). Vous pouvez aussi la lancer à la main avec **Run workflow**.
3. Quand elle est verte, ouvrez la page **Releases** du dépôt (colonne de droite) : le fichier `Deckline.apk` s'y trouve. Il est aussi dans les « Artifacts » de la tâche.
4. Sur le téléphone, ouvrez la page Releases dans le navigateur, téléchargez `Deckline.apk` et touchez-le. Android demandera d'autoriser l'installation depuis cette source (une seule fois).

L'application s'ouvre en mode paysage. L'APK est signé avec la clé de débogage : il s'installe sans problème, mais il ne convient pas à une publication sur le Play Store.

Les polices viennent de Google Fonts, donc le premier lancement demande internet. Sans connexion, l'application affiche des polices système, le reste fonctionne.

## Sur téléphone (sans APK)

Utilisez le mode paysage. Le bouton « Plein écran » (écrans tactiles) passe en plein écran et tente de verrouiller l'orientation. Depuis Chrome Android, « Ajouter à l'écran d'accueil » installe l'application en plein écran paysage.

## Fichiers

| Fichier | Rôle |
|---|---|
| `index.html` | Structure de la page |
| `style.css` | Styles, dont la mise en page paysage |
| `app.js` | Moteur audio, platines, mixeur, effets, pads, bibliothèque |
| `manifest.webmanifest`, `icon*.png/svg` | Installation sur l'écran d'accueil |
| `.github/workflows/pages.yml` | Déploiement GitHub Pages |
| `.github/workflows/android.yml` | Compilation de l'APK Android |
| `package.json`, `capacitor.config.json`, `assets/splash.png` | Configuration de l'application Android |
