package com.example.alarmshock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Reprogramme l'alarme après un redémarrage ou une mise à jour de l'app. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val cfg = AlarmStore.load(context)
        if (cfg.enabled) {
            AlarmScheduler.schedule(context, cfg)
        }
    }
}
