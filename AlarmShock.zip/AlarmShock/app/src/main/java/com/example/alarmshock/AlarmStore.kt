package com.example.alarmshock

import android.content.Context

data class AlarmConfig(
    val hour: Int = 7,
    val minute: Int = 0,
    val enabled: Boolean = false,
    val repeatDaily: Boolean = true
)

object AlarmStore {
    private const val PREFS = "alarm_prefs"

    fun load(ctx: Context): AlarmConfig {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return AlarmConfig(
            hour = p.getInt("hour", 7),
            minute = p.getInt("minute", 0),
            enabled = p.getBoolean("enabled", false),
            repeatDaily = p.getBoolean("repeatDaily", true)
        )
    }

    fun save(ctx: Context, cfg: AlarmConfig) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("hour", cfg.hour)
            .putInt("minute", cfg.minute)
            .putBoolean("enabled", cfg.enabled)
            .putBoolean("repeatDaily", cfg.repeatDaily)
            .apply()
    }
}
