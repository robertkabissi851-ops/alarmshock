package com.example.alarmshock

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var picker: TimePicker
    private lateinit var enableSwitch: Switch
    private lateinit var repeatSwitch: Switch
    private lateinit var status: TextView
    private var loading = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = dp(20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "Alarme Choc"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
        }
        picker = TimePicker(this).apply { setIs24HourView(true) }
        enableSwitch = Switch(this).apply {
            text = "Activer l'alarme"
            textSize = 18f
            setPadding(0, dp(12), 0, dp(12))
        }
        repeatSwitch = Switch(this).apply {
            text = "Répéter chaque jour"
            textSize = 18f
            setPadding(0, dp(12), 0, dp(12))
        }
        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(16), 0, 0)
        }
        val info = TextView(this).apply {
            text = "Quand l'alarme sonne, donnez un léger choc à l'appareil pour l'arrêter."
            textSize = 14f
            setPadding(0, dp(24), 0, 0)
        }

        root.addView(title)
        root.addView(picker)
        root.addView(enableSwitch)
        root.addView(repeatSwitch)
        root.addView(status)
        root.addView(info)
        setContentView(ScrollView(this).apply { addView(root) })

        picker.setOnTimeChangedListener { _, _, _ -> if (!loading) onChanged() }
        enableSwitch.setOnCheckedChangeListener { _, _ -> if (!loading) onChanged() }
        repeatSwitch.setOnCheckedChangeListener { _, _ -> if (!loading) onChanged() }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        // Recharge l'état (une alarme non répétée se désactive après avoir sonné).
        val cfg = AlarmStore.load(this)
        loading = true
        picker.hour = cfg.hour
        picker.minute = cfg.minute
        enableSwitch.isChecked = cfg.enabled
        repeatSwitch.isChecked = cfg.repeatDaily
        loading = false
        refreshStatus(cfg)
    }

    private fun onChanged() {
        val cfg = AlarmConfig(
            hour = picker.hour,
            minute = picker.minute,
            enabled = enableSwitch.isChecked,
            repeatDaily = repeatSwitch.isChecked
        )
        AlarmStore.save(this, cfg)

        if (cfg.enabled) {
            val trigger = AlarmScheduler.schedule(this, cfg)
            val diff = trigger - System.currentTimeMillis()
            val h = diff / 3_600_000
            val m = (diff / 60_000) % 60
            Toast.makeText(this, "Alarme dans $h h $m min", Toast.LENGTH_SHORT).show()
            checkFullScreenIntentPermission()
        } else {
            AlarmScheduler.cancel(this)
        }
        refreshStatus(cfg)
    }

    private fun refreshStatus(cfg: AlarmConfig) {
        val hhmm = String.format("%02d:%02d", cfg.hour, cfg.minute)
        status.text = if (cfg.enabled) {
            "Alarme activée à $hhmm" + if (cfg.repeatDaily) " (tous les jours)" else " (une seule fois)"
        } else {
            "Alarme désactivée"
        }
    }

    private fun checkFullScreenIntentPermission() {
        if (Build.VERSION.SDK_INT >= 34) {
            val nm = getSystemService(NotificationManager::class.java)
            if (!nm.canUseFullScreenIntent()) {
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
