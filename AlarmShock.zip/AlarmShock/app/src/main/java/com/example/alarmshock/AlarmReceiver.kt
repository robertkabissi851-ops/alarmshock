package com.example.alarmshock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val cfg = AlarmStore.load(context)
        if (!cfg.enabled) return

        if (cfg.repeatDaily) {
            // Reprogramme déjà la prochaine occurrence (demain à la même heure).
            AlarmScheduler.schedule(context, cfg)
        } else {
            AlarmStore.save(context, cfg.copy(enabled = false))
        }

        context.startForegroundService(Intent(context, AlarmService::class.java))
    }
}
