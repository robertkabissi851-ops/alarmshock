package com.example.alarmshock

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Écran plein écran affiché quand l'alarme sonne (même téléphone verrouillé). */
class AlarmRingActivity : Activity() {

    private val stoppedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            finish()
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }

        val time = TextView(this).apply {
            text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            textSize = 72f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val hint = TextView(this).apply {
            text = "Donnez un léger choc à l'appareil pour arrêter l'alarme"
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 64)
        }
        val stop = Button(this).apply {
            text = "Arrêter"
            setOnClickListener {
                startService(
                    Intent(this@AlarmRingActivity, AlarmService::class.java)
                        .setAction(AlarmService.ACTION_STOP)
                )
                finish()
            }
        }
        root.addView(time)
        root.addView(hint)
        root.addView(stop)
        setContentView(root)

        val filter = IntentFilter(AlarmService.ACTION_STOPPED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stoppedReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(stoppedReceiver, filter)
        }
    }

    override fun onResume() {
        super.onResume()
        // Si l'alarme est déjà arrêtée (choc détecté avant l'affichage), on ferme.
        if (!AlarmService.isRinging) finish()
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(stoppedReceiver)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }
}
