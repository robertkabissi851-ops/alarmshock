package com.example.alarmshock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import kotlin.math.sqrt

/**
 * Service au premier plan : joue la sonnerie, fait vibrer, et écoute l'accéléromètre.
 * Un léger choc sur l'appareil (accélération > SHOCK_THRESHOLD) arrête l'alarme.
 */
class AlarmService : Service(), SensorEventListener {

    companion object {
        const val ACTION_STOP = "com.example.alarmshock.STOP"
        const val ACTION_STOPPED = "com.example.alarmshock.STOPPED"

        private const val CHANNEL_ID = "alarm_ring"
        private const val NOTIF_ID = 42

        /** Seuil du choc en m/s² (hors gravité). Baisser = plus sensible. */
        const val SHOCK_THRESHOLD = 6f

        /** Délai après le début de la sonnerie pendant lequel les chocs sont ignorés. */
        const val ARM_DELAY_MS = 2000L

        /** Arrêt automatique de sécurité. */
        const val MAX_RING_MS = 5 * 60 * 1000L

        @Volatile
        var isRinging = false
    }

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var sensorManager: SensorManager? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var startTime = 0L
    private var usesLinearSensor = false
    private val gravity = FloatArray(3)
    private var stopped = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAlarm()
            return START_NOT_STICKY
        }
        if (isRinging) return START_NOT_STICKY

        isRinging = true
        stopped = false
        startTime = SystemClock.elapsedRealtime()

        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "alarmshock:ring").apply {
            acquire(MAX_RING_MS + 10_000L)
        }

        startSound()
        startVibration()
        startShockDetection()

        handler.postDelayed({ stopAlarm() }, MAX_RING_MS)
        return START_NOT_STICKY
    }

    private fun startSound() {
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@AlarmService, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun startVibration() {
        vibrator = getSystemService(Vibrator::class.java)
        vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 600), 0))
    }

    private fun startShockDetection() {
        val sm = getSystemService(SensorManager::class.java)
        sensorManager = sm
        val linear = sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        val sensor = linear ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        usesLinearSensor = linear != null
        if (sensor != null) {
            sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        val magnitude: Float
        if (usesLinearSensor) {
            // Accélération linéaire : la gravité est déjà retirée.
            magnitude = sqrt(x * x + y * y + z * z)
        } else {
            // Repli : filtre passe-haut pour isoler le choc de la gravité.
            val a = 0.8f
            gravity[0] = a * gravity[0] + (1 - a) * x
            gravity[1] = a * gravity[1] + (1 - a) * y
            gravity[2] = a * gravity[2] + (1 - a) * z
            val lx = x - gravity[0]
            val ly = y - gravity[1]
            val lz = z - gravity[2]
            magnitude = sqrt(lx * lx + ly * ly + lz * lz)
        }

        if (SystemClock.elapsedRealtime() - startTime < ARM_DELAY_MS) return
        if (magnitude > SHOCK_THRESHOLD) {
            stopAlarm()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun stopAlarm() {
        if (stopped) return
        stopped = true
        isRinging = false
        handler.removeCallbacksAndMessages(null)

        sensorManager?.unregisterListener(this)
        sensorManager = null

        try {
            player?.stop()
        } catch (_: Exception) {
        }
        player?.release()
        player = null

        vibrator?.cancel()
        vibrator = null

        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null

        sendBroadcast(Intent(ACTION_STOPPED).setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopAlarm()
        isRinging = false
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(CHANNEL_ID, "Alarme", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null) // le son est géré par le MediaPlayer
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val ringIntent = Intent(this, AlarmRingActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            this, 0, ringIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Alarme")
            .setContentText("Donnez un léger choc à l'appareil pour arrêter")
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
    }
}
