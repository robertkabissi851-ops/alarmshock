# Alarme Choc

Application d'alarme Android (Kotlin, aucune dépendance externe).
Particularité de la v1 : **l'alarme s'arrête quand on donne un léger choc à l'appareil**.

## Lancer le projet
1. Ouvrir ce dossier dans Android Studio (Koala ou plus récent).
2. Laisser Gradle se synchroniser (JDK 17).
3. Brancher un téléphone réel (l'émulateur ne gère pas bien les chocs) et lancer.

## Fonctionnement
- `AlarmScheduler` : programme l'alarme avec `AlarmManager.setAlarmClock()` (exacte, traverse le mode Doze).
- `AlarmReceiver` : déclenché à l'heure dite, reprogramme le lendemain si « répéter » est actif, démarre le service.
- `AlarmService` : service au premier plan, joue la sonnerie d'alarme, fait vibrer, écoute l'accéléromètre.
- `AlarmRingActivity` : écran plein écran avec bouton « Arrêter » de secours.
- `BootReceiver` : reprogramme l'alarme après redémarrage.

## Régler la sensibilité du choc
Dans `AlarmService.kt` (companion object) :
- `SHOCK_THRESHOLD` (6 m/s² par défaut) : baisser = plus sensible, monter = il faut taper plus fort.
- `ARM_DELAY_MS` (2 s) : délai initial pendant lequel les chocs sont ignorés.

Si la vibration du téléphone arrête l'alarme toute seule, monter le seuil ou désactiver `startVibration()`.

## Limites connues de la v1
- Une seule alarme, un seul son (sonnerie d'alarme par défaut du téléphone).
- Certains constructeurs (Xiaomi, Huawei, Oppo...) imposent des optimisations batterie : il peut falloir autoriser l'app en « sans restriction ».
- Pas de snooze ni d'écran de liste d'alarmes.
